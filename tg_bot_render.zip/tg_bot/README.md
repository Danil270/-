# 📱 Telegram Блокнот-Бот

Бот с личным блокнотом для каждого пользователя и панелью администратора.

---

## 🚀 Деплой на Render.com (бесплатно)

### Шаг 1 — Создай бота в Telegram

1. Открой [@BotFather](https://t.me/BotFather) в Telegram
2. Напиши `/newbot`
3. Придумай имя и username (должен оканчиваться на `bot`)
4. Скопируй **токен** — выглядит так: `7123456789:AAFxxxxxxxxxxxxxxxxxxxxxx`

---

### Шаг 2 — Узнай свой Telegram ID

1. Открой [@userinfobot](https://t.me/userinfobot) и напиши `/start`
2. Скопируй своё `Id` (просто цифры, например `123456789`)

---

### Шаг 3 — Загрузи код на GitHub

1. Зайди на [github.com](https://github.com) → **New repository**
2. Назови репозиторий, например `my-tg-bot`, нажми **Create repository**
3. Нажми **uploading an existing file** и загрузи все файлы из этой папки
4. Нажми **Commit changes**

---

### Шаг 4 — Задеплой на Render

1. Зайди на [render.com](https://render.com) → войди через GitHub
2. Нажми **New +** → **Background Worker**
3. Выбери свой репозиторий `my-tg-bot`
4. Настройки заполнятся автоматически из `render.yaml`
5. Прокрути вниз до **Environment Variables** и добавь:
   - `BOT_TOKEN` = твой токен от BotFather
   - `ADMIN_ID`  = твой Telegram ID
6. Нажми **Create Background Worker** — бот запустится! ✅

> **Бесплатный план Render:** Background Worker работает 24/7 бесплатно.

---

## 👤 Что умеет пользователь

| Действие | Описание |
|---|---|
| 📋 Мой блокнот | Просмотр всех своих данных |
| ✏️ Редактировать данные | Изменить имя, телефон, задачи |
| 📋 Мои задачи | Список задач с отметкой выполнения |

---

## 👑 Что умеет админ

| Действие | Описание |
|---|---|
| 👥 Все пользователи | Список всех, нажми на любого — увидишь его блокнот |
| ✉️ Написать менеджеру | Выбери пользователя и напиши ему прямо из бота |
| 📢 Рассылка | Отправить сообщение сразу всем |

---

## 🔧 Локальный запуск (для теста на ПК)

```bash
pip install -r requirements.txt
export BOT_TOKEN="твой_токен"
export ADMIN_ID="твой_id"
python bot.py
```

На Windows вместо `export` используй:
```cmd
set BOT_TOKEN=твой_токен
set ADMIN_ID=твой_id
python bot.py
```
